 package com.capgemini.tcc.dao;
import com.capgemini.tcc.CommonConnection.Commonconnection;
import java.time.LocalDate;
import java.sql.*;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.service.*;
interface IPatientDAO
{
	int addPatientDetails(PatientBean patient) throws SQLException;
	PatientBean getPatientDetails(int patientId) throws SQLException, Exception;
}
public class PatientDAO implements IPatientDAO{
	Connection cn;
	PreparedStatement ps,ps1;
	Statement stmt;
	ResultSet rs;
	public int addPatientDetails(PatientBean patient) throws SQLException
	{
		cn=Commonconnection.getCon();
		ps=cn.prepareStatement("INSERT into  Patient values(Patient_id_Seq.nextval,?,?,?,?,SYSDATE)");
		//ps.setInt(1, patient.getPatient_id());
		ps.setString(1, patient.getPatient_name());
		ps.setInt(2,patient.getAge()); 
		ps.setLong(3, patient.getPhone());
		ps.setString(4, patient.getDescription());
		ps.executeUpdate();
		ps1=cn.prepareStatement("select patient_id from Patient where Patient_name=?");
		ps1.setString(1, patient.getPatient_name());
		rs=ps1.executeQuery();
		while(rs.next()) {
		System.out.println("Patient Information stored successfully for"+rs.getString(1));
		}
		return 0;
		
	}
	 public PatientBean getPatientDetails(int patientId) throws Exception
	 {
		 int id=patientId;
		 cn=Commonconnection.getCon(); 
		 stmt=cn.createStatement();
		 try {
int i=stmt.executeUpdate("select * from Patient where patient_id="+id);
if(i>0)
{
	ResultSet rs=stmt.executeQuery("select * from Patient where patient_id="+id);
	while(rs.next())
	{
	System.out.println("Name of the Patient:"+rs.getString(2)+"\nAge:\t"+rs.getInt(3)+"\nPhone Number:"
	+ rs.getLong(4)+"\nDescription:  "+rs.getString(5)+"\nConsultation Date:"+LocalDate.now());
		}
}
else
{
	throw new UserException();
}
		 }	 
		 catch(Exception e)
		 {
			 System.out.println(e);
		 }
		 return null;
	 }
}
  class UserException extends Exception
{
	public String toString()
	{
		return"There is no patient with this ID";
	}
}
